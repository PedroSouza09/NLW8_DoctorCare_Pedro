// String (textos)
// Number (número)
// Boolean (true | false)

function onScroll() {
  if (true) {
    navigation.classList.add('scroll')
  }
}
